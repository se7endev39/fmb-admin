/** To be Refactored when switch to CSS in JS */

export const Colors = {
    green: '#8BC34A',
    orange: 'orange',
    amber: '#FFC107',
    teal: '#1DE9B6',
    purple: 'purple',
    cyan: '#00BCD4',
    pink: '#F06292'
}