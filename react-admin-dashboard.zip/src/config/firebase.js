// Replace these credentials with your Firebase credentials

export const firebaseConfig = {
  apiKey: "AIzaSyBZR3erPUNqzSCYg6jsnG5U8JEvdRp_fdY",
  authDomain: "fmb-ny.firebaseapp.com",
  databaseURL: "https://fmb-ny-default-rtdb.firebaseio.com",
  projectId: "fmb-ny",
  storageBucket: "fmb-ny.appspot.com",
  messagingSenderId: "71668661170",
};
