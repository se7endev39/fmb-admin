import React from 'react';
import Header from '../components/Header';

const Products = () =>
  <div className='productsContainer'>
    <Header pageTitle='Products' />
    <div className='mainContainer'>
      <h2>This is Products</h2>
    </div>
  </div>;

export default Products;