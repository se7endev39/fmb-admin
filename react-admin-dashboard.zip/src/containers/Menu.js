import React from 'react';

import MenuItem from '../components/MenuItem';

class Menu extends React.Component {

  state = { open: false };

  render()  {
    return (
      <div>
        <div className='brand'>
          <h2 className='title'></h2>
        </div>
        <ul>
          <MenuItem link='/' linkText='Dashboard' iconName='tachometer' />
          <MenuItem link='/profile' linkText='Home' iconName='cog' />
          <MenuItem link='/shop' linkText='Today Thaalis' iconName='shopping-cart' />
          <MenuItem link='/products' linkText='FeedBack' iconName='tags' />
          <MenuItem link='/orders' linkText='Users' iconName='list' />
          <MenuItem link='/customers' linkText='Menu' iconName='group' />
          <MenuItem link='/analytics' linkText='Calendar' iconName='bar-chart' />
          <MenuItem link='/settings' linkText='Settings' iconName='gear' />
        </ul> 
      </div>
      
    );
  }
}

export default Menu;