import React from 'react';
import Header from '../components/Header';

const Orders = () =>
  <div className='ordersContainer'>
    <Header pageTitle='Orders' />
    <div className='mainContainer'>
      <h2>This is Orders</h2>
    </div>
  </div>;

export default Orders;